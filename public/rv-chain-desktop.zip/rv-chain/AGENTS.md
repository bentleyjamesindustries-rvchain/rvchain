# RV Chain

Powersports parts board for ATV, off-road truck, dirt bike, racecar (Dirt or Asphalt), and snowmobile.

## Product

- Identify is the front door: photo, general summary, voice description as ground truth, pick ATV / Truck / Dirt bike / Racecar, Dirt|Asphalt if racing, then search the board or list the part.
- Camera and gallery are split. Camera uses capture=environment. Gallery has no capture attribute.
- Do not say "make the ad". Voice edit is "Edit with voice description".
- Market filters those same categories. Snowmobile is an extra tile.
- Sponsors is a blank reserved page (rightmost phone tab).
- EN/ES toggle in the header. Dirt/Asphalt stay as racing product terms.
- Auth OFF. Data is localStorage/zustand, not a shared database.
- No camping, campers, campgrounds, Trailhead, ride log, forum, games, crew, or trip planner.
- No whole-vehicle sales. No escrow / middleman.

## Stack

TanStack Start/Router, React 19, Tailwind v4, zustand persist (`rv-chain`, `trailscan-ads`). Identify uses server-only `XAI_API_KEY` (grok-4.5 vision). Do not put the key in a `VITE_` variable.

## Brand

Metal #07080b, ice-blue #5aa6d6, gold #c4b08a, cream #e8eef4, Outfit. Lineup background `/public/rvchain-scene-bg.jpg`. Beanie mark `/public/rvchain-mark.jpg`.
