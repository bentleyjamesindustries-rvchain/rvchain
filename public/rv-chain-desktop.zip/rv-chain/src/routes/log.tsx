import { Navigate, createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/log")({ component: RedirectHome });

function RedirectHome() {
  return <Navigate to="/" />;
}
