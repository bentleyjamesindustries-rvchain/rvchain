import { Navigate, createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/forum")({ component: RedirectHome });

function RedirectHome() {
  return <Navigate to="/" />;
}
