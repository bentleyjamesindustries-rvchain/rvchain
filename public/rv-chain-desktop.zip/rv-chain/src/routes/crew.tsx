import { Navigate, createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/crew")({ component: RedirectHome });

function RedirectHome() {
  return <Navigate to="/" />;
}
