import { Navigate, createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/explorer")({ component: RedirectHome });

function RedirectHome() {
  return <Navigate to="/" />;
}
