import { Navigate, createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/trip")({ component: RedirectHome });

function RedirectHome() {
  return <Navigate to="/" />;
}
