import { Navigate, createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/ai")({ component: AiRedirect });

function AiRedirect() {
  return <Navigate to="/scan" />;
}
