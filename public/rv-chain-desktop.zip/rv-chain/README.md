# RV Chain — open this in Grok Build CLI

Powersports parts board: Identify, Market, Sponsors. EN/ES. No camping. No whole-vehicle sales.

This zip is the project folder. Grok Build on the web cannot write to your desktop. You download this once, then run `grok` inside the folder.

## 1. Install Grok Build CLI (if you do not have it)

Docs: https://x.ai/cli

**Windows (PowerShell)**

```powershell
irm https://x.ai/cli/install.ps1 | iex
```

**macOS / Linux**

```bash
curl -fsSL https://x.ai/cli/install.sh | bash
```

Then sign in when it asks.

## 2. Put this folder on your machine

1. Download `rv-chain-desktop.zip` (home screen **Download files**, or the file in this chat).
2. Unzip it. You should see a folder named `rv-chain`.
3. In a terminal:

**Windows**

```powershell
cd $HOME\Downloads\rv-chain
grok
```

**macOS / Linux**

```bash
cd ~/Downloads/rv-chain
grok
```

If the unzip landed somewhere else, `cd` to that `rv-chain` folder first. Working directory is what Grok Build sees.

## 3. First prompt in the CLI

```
This is RV Chain. Read README.md and AGENTS.md, then keep going from the live Grok Build web app: Identify + Market + blank Sponsors, powersports only.
```

## Run the website yourself (optional)

Needs Node 22 and an xAI key for Identify.

```bash
npm install
cp .env.example .env
# put XAI_API_KEY in .env
npm run dev
```

Publish later with `npm run build` then Vercel. Set `XAI_API_KEY` and `VITE_AUTH_ENABLED=false` on the host. Point the domain at rv-chain.com.
